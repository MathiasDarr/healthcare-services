package org.mddarr.relational_appointment_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationalAppointmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelationalAppointmentServiceApplication.class, args);
	}

}
